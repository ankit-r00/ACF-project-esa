<div class="wpallimport-collapsed closed wpallimport-section scheduling">
	<div class="wpallimport-content-section">
		<div class="wpallimport-collapsed-header disabled"
        	title="<?php _e("To run this import on a schedule you must use the 'Download from URL' or 'Use existing file' options in Step 1.", PMXI_Plugin::LANGUAGE_DOMAIN);?>">
			<h3 id="scheduling-title"><?php _e('Scheduling Options','wp_all_import_plugin');?>                
                <a href="#help" class="wpallimport-help" style="position: relative; top: -2px; margin-left: 0; width: 20px; height: 20px;"  title="<?php _e("To run this import on a schedule you must use the 'Download from URL' or 'Use existing file' option on the Import Settings page.", PMXI_Plugin::LANGUAGE_DOMAIN);?>">?</a>                
            </h3>
        </div>
		<div class="wpallimport-collapsed-content" style="padding: 0;">
			<div class="wpallimport-collapsed-content-inner">
				
			</div>
		</div>		
	</div>
</div>