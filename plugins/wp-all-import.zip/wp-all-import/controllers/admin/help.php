<?php 
/**
 * Admin Help page
 *
 * @author Maksym Tsypliakov <maksym.tsypliakov@gmail.com>
 */
class PMXI_Admin_Help extends PMXI_Controller_Admin {
	
	public function index() {
		$this->render();
	}
}